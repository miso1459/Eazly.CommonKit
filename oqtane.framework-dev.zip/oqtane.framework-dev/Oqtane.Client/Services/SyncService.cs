using Oqtane.Models;
using System.Threading.Tasks;
using System.Net.Http;
using System;
using Oqtane.Documentation;
using Oqtane.Shared;
using System.Globalization;

namespace Oqtane.Services
{
    /// <summary>
    /// Service to retrieve <see cref="Sync"/> information.
    /// </summary>
    public interface ISyncService
    {
        /// <summary>
        /// Get sync events
        /// </summary>
        /// <param name="lastSyncDate"></param>
        /// <returns></returns>
        Task<Sync> GetSyncEventsAsync(DateTime lastSyncDate);
    }

    /// <inheritdoc cref="ISyncService" />
    [PrivateApi("Don't show in the documentation, as everything should use the Interface")]
    public class SyncService : ServiceBase, ISyncService
    {
        public SyncService(HttpClient http, SiteState siteState) : base(http, siteState) { }

        private string ApiUrl => CreateApiUrl("Sync");

        /// <inheritdoc />
        public async Task<Sync> GetSyncEventsAsync(DateTime lastSyncDate)
        {
            return await GetJsonAsync<Sync>($"{ApiUrl}/{lastSyncDate.ToString("yyyyMMddHHmmssfff", CultureInfo.InvariantCulture)}");
        }
    }
}
